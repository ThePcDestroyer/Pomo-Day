const $=id=>document.getElementById(id);

// Bullet presets: [name, diameter mm, mass g, velocity m/s, hardness k]
const BU=[
  ["9×19 mm FMJ",9,8,360,.3],
  ["9×19 mm 7N21 AP",9,5.3,460,.85],
  ["5.7×28 mm SS190",5.7,2.02,715,.65],
  ["4.6×30 mm DM11 AP",4.6,2.0,685,.7],
  ["5.56×45 mm M193",5.56,3.56,975,.25],
  ["5.56×45 mm M855 (steel tip)",5.56,4,920,.6],
  ["5.56×45 mm M995 (WC AP)",5.56,3.4,1030,1.45],
  ["5.45×39 mm 7N22 AP",5.45,3.68,890,.95],
  ["7.62×39 mm PS (M43)",7.62,7.9,715,.4],
  ["7.62×39 mm BP (AP)",7.62,7.9,730,.9],
  ["7.62×51 mm M80 ball",7.82,9.65,840,.4],
  ["7.62×51 mm M61 AP",7.82,9.75,838,.95],
  ["7.62×51 mm M993 (WC AP)",7.62,8.2,930,1.5],
  ["7.62×54R B-32 API",7.62,10.4,860,1.1],
  [".338 Lapua Mag AP",8.58,16.2,900,1.2],
  [".50 BMG M33 ball",12.95,42.9,887,.45],
  [".50 BMG M2 AP",12.95,45.9,887,1.0],
  [".50 BMG M903 SLAP (WC)",7.62,23.2,1219,1.5],
  ["12.7×108 mm B-32 API",12.95,48.3,820,1.1],
  ["14.5×114 mm B-32 API",14.5,64.4,976,1.15],
  ["20×102 mm M50 (Vulcan)",20,103,1030,.85],
  ["25×137 mm M791 APDS",25,134,1345,1.4],
  ["30×173 mm APFSDS (GAU-8)",30,235,1385,1.6]
];

// Materials: [name, density kg/m3, yield MPa, cp J/kgK, melt °C, friction, brittleness, color, canRicochet, E GPa, failureStrain]
const MA=[
  ["RHA steel",7850,1100,470,1500,.20,.12,"#8a95a3",1,200,.14],
  ["Mild steel",7850,350,470,1500,.22,.05,"#9aa4a0",1,200,.26],
  ["Hardened steel (AR500)",7850,1500,470,1500,.18,.32,"#6b7684",1,205,.08],
  ["Ultra-hard steel (MIL-46100)",7850,1750,470,1500,.18,.40,"#55606e",1,210,.065],
  ["Titanium Ti-6Al-4V",4430,1050,526,1650,.36,.22,"#a99f8f",1,114,.12],
  ["Aluminium 5083",2660,320,900,600,.34,.10,"#b8c4d0",1,71,.20],
  ["Aluminium 7075-T6",2810,540,960,635,.30,.16,"#c4d0dc",1,72,.14],
  ["Alumina ceramic (Al2O3)",3900,3200,880,2070,.28,.94,"#e0d6c4",1,160,.012],
  ["Boron carbide (B4C)",2520,4200,960,2450,.20,.97,"#d4cfc0",1,180,.010],
  ["Silicon carbide (SiC)",3210,3600,670,2700,.24,.95,"#c8c0b0",1,170,.011],
  ["UHMWPE (Dyneema)",970,550,1900,150,.10,.25,"#d9c26a",0,32,.32],
  ["Aramid (Kevlar 29)",1440,480,1420,450,.18,.28,"#c9a227",0,38,.24],
  ["Concrete (C35)",2400,45,650,1200,.50,.75,"#a8a29a",1,30,.025],
  ["Glass (Borosilicate)",2500,180,750,820,.28,.88,"#9fd0e6",1,65,.018],
  ["Wood (White Oak)",750,65,2400,320,.40,.45,"#8b6a4a",0,12,.09],
  ["Composite (NERA)",2200,850,1050,650,.16,.40,"#7e8c9c",1,55,.22],
  ["Reactive (ERA - Kontakt)",1900,650,920,420,.15,.85,"#b86b52",1,45,.06],
  ["Tungsten Heavy Alloy",17500,1350,134,3400,.20,.25,"#636675",1,260,.09],
  ["Copper (OFHC)",8960,220,385,1085,.28,.06,"#c87d55",1,115,.35]
];

// Johnson-Cook parameters: A (MPa), B (MPa), n, C (strain-rate sensitivity), m (thermal softening)
const JC={
  "RHA steel":{A:792,B:510,n:.26,C:.014,m:1.03},
  "Mild steel":{A:250,B:320,n:.38,C:.022,m:1.00},
  "Hardened steel (AR500)":{A:1250,B:620,n:.28,C:.011,m:.92},
  "Ultra-hard steel (MIL-46100)":{A:1480,B:680,n:.25,C:.010,m:.88},
  "Titanium Ti-6Al-4V":{A:862,B:331,n:.34,C:.012,m:.80},
  "Aluminium 5083":{A:167,B:596,n:.55,C:.001,m:.86},
  "Aluminium 7075-T6":{A:520,B:477,n:.52,C:.002,m:1.00},
  "Alumina ceramic (Al2O3)":{A:3000,B:150,n:.15,C:.004,m:1.10},
  "Boron carbide (B4C)":{A:3900,B:180,n:.12,C:.005,m:1.10},
  "Silicon carbide (SiC)":{A:3400,B:160,n:.14,C:.004,m:1.10},
  "UHMWPE (Dyneema)":{A:280,B:450,n:.55,C:.018,m:1.25},
  "Aramid (Kevlar 29)":{A:250,B:380,n:.48,C:.015,m:1.15},
  "Concrete (C35)":{A:38,B:45,n:.30,C:.008,m:.60},
  "Glass (Borosilicate)":{A:160,B:60,n:.20,C:.005,m:.70},
  "Wood (White Oak)":{A:50,B:35,n:.32,C:.004,m:.65},
  "Composite (NERA)":{A:550,B:500,n:.38,C:.012,m:.95},
  "Reactive (ERA - Kontakt)":{A:450,B:250,n:.25,C:.008,m:1.00},
  "Tungsten Heavy Alloy":{A:1150,B:420,n:.18,C:.016,m:1.00},
  "Copper (OFHC)":{A:90,B:292,n:.31,C:.025,m:1.09}
};

const BP=[["v","Velocity",50,1800,5,"m/s"],["m","Mass",.5,300,.1,"g"],["d","Diameter",3,35,.1,"mm"],["k","Penetrator hardness",.1,1.6,.05,""],["dir","Direction",-180,180,1,"°"]];
const PP=[["w","Thickness",.5,120,.5,"mm"],["h","Height",20,300,5,"mm"],["rot","Rotation",-180,180,1,"°"]];

const nb=(pi,x=-45,y=0)=>{const b=BU[pi]||BU[0];return{x,y,dir:0,d:b[1],m:b[2],v:b[3],k:b[4],pre:pi}};
const np=(x=0,y=0,w=22,h=100,rot=0,mat=0)=>({x,y,w,h,rot,mat});

let sc={b:[nb(2)],p:[np(0,0,18,100,0,0)],drawn:[]},sel={t:'b',i:0};
let drawMode='select',drawMat=0,drawSize=3,drawPoints=[],isDrawing=false,lineCursor=null;
let last=0,seed=7,v50busy=false;
let PS=null,psRun=false,graphData={t:[],v:[],ke:[],f:[]};

const rnd=()=>(seed=(seed*1664525+1013904223)>>>0)/4294967296;


// Fast Johnson-Cook flow stress (Pa): parameters cached on the body object
function jcFast(B,ep,edot,th){
  const jc=B.jc===undefined?(B.jc=JC[B.name]||null):B.jc,t=th>.98?.98:th>0?th:0;
  if(!jc)return B.Y*(1-t);
  const st=jc.A+(ep>1e-9?jc.B*Math.pow(ep,jc.n):0),rt=edot>1?1+jc.C*Math.log(edot):1,tt=t>0?1-Math.pow(t,jc.m):1,v=st*rt*tt*1e6;
  return v>5e6?v:5e6;
}
// Give every body object the same property order so the hot loops stay monomorphic (big speed-up)
function normBodies(arr){
  const keys=[...new Set(arr.flatMap(o=>Object.keys(o)))];if(!keys.includes('jc'))keys.push('jc');
  return arr.map(o=>{const n={};for(const k of keys)n[k]=o[k]===undefined?(k==='jc'?undefined:0):o[k];return n});
}
// Helper: Johnson-Cook flow stress (Pa)
function jcStress(matName,baseY_MPa,ep,edot,th){
  const jc=JC[matName];
  const tStar=Math.min(.98,Math.max(0,th));
  if(!jc)return baseY_MPa*1e6*(1-tStar);
  const strainTerm=jc.A+jc.B*Math.pow(Math.max(0,ep),jc.n);
  const rateTerm=1+jc.C*Math.log(Math.max(1,edot));
  const thermTerm=1-Math.pow(tStar,jc.m);
  return Math.max(5e6,strainTerm*rateTerm*thermTerm*1e6);
}

// ---------- Nodes & Particles Engine (2D Bonded-Lattice Dynamics + Johnson-Cook) ----------
function build(){
  const bodies=[],X=[],Y=[],VX=[],VY=[],BI=[],FIX=[],bd=sc.b;
  const maxD=Math.max(8,...bd.map(b=>b.d)),minD=Math.min(12,...bd.map(b=>b.d));
  let dx=Math.min(+$('res').value,.11*minD)/1e3;
  const est=()=>sc.p.reduce((a,p)=>a+p.w*p.h,0)/1e6/dx/dx+bd.length*2200*(.6e-3/dx)**2;
  while(est()>110000)dx*=1.15;
  const dzP=Math.PI/4*maxD/1e3;

  // Rectangular armor plates
  sc.p.forEach((p,pi)=>{
    const q=MA[p.mat]||MA[0],r=p.rot*Math.PI/180,cr=Math.cos(r),sr=Math.sin(r);
    const E=(q[9]||150)*1e9,ef=q[10]||.08;
    const B={
      name:q[0],matIdx:p.mat,E,Y:q[2]*1e6,rho:q[1],cp:q[3],Tm:q[4],mu:q[5],
      br:q[6]>.5,ef,col:q[7],k:.5*E*dzP,m:q[1]*dx*dx*dzP,plate:1,plateIdx:pi,
      era:q[0].includes("ERA"),nera:q[0].includes("NERA"),eraTriggered:0,s:X.length
    };
    bodies.push(B);
    const w=p.w/1e3,h=p.h/1e3;
    for(let a=dx/2;a<w;a+=dx){
      for(let b=-h/2+dx/2;b<h/2;b+=dx){
        const lx=a-w/2;
        X.push(p.x/1e3+lx*cr-b*sr);
        Y.push(p.y/1e3+lx*sr+b*cr);
        VX.push(0);VY.push(0);
        BI.push(bodies.length-1);
        FIX.push(Math.abs(b)>h/2-2.5*dx?1:0);
      }
    }
    B.e=X.length;
  });

  // Freeform drawn armor (Fixed unit scaling: pt.x & pt.y are in mm, dxMm is in mm!)
  if(sc.drawn&&sc.drawn.length){
    const groups=new Map(),dxMm=dx*1e3;
    sc.drawn.forEach(sh=>{
      const cells=new Set();
      const radCells=Math.max(1,Math.round((sh.size||3)/dxMm));
      if(sh.type==='brush'){
        sh.points.forEach(pt=>{
          const cx=Math.round(pt.x/dxMm),cy=Math.round(pt.y/dxMm);
          for(let a=-radCells;a<=radCells;a++)
            for(let b=-radCells;b<=radCells;b++)
              if(a*a+b*b<=radCells*radCells+.5)cells.add((cx+a)+','+(cy+b));
        });
      }else{
        for(let i=0;i<sh.points.length-1;i++){
          const p0=sh.points[i],p1=sh.points[i+1];
          const lenMm=Math.hypot(p1.x-p0.x,p1.y-p0.y),steps=Math.max(1,Math.ceil(lenMm/(dxMm*.6)));
          const half=Math.max(1,Math.round((sh.size||3)/(2*dxMm)));
          for(let t=0;t<=steps;t++){
            const u=t/steps,x=p0.x+u*(p1.x-p0.x),y=p0.y+u*(p1.y-p0.y);
            const cx=Math.round(x/dxMm),cy=Math.round(y/dxMm);
            for(let a=-half;a<=half;a++)
              for(let b=-half;b<=half;b++)
                if(a*a+b*b<=half*half+.5)cells.add((cx+a)+','+(cy+b));
          }
        }
      }
      const key=sh.material||0;
      if(!groups.has(key))groups.set(key,new Set());
      const gSet=groups.get(key);
      for(const c of cells)if(gSet.size<25000)gSet.add(c);
    });
    groups.forEach((cellset,matIdx)=>{
      if(!cellset.size)return;
      const q=MA[matIdx]||MA[0],E=(q[9]||150)*1e9,ef=q[10]||.08;
      const B={
        name:q[0]+' (Drawn)',matIdx,E,Y:q[2]*1e6,rho:q[1],cp:q[3],Tm:q[4],mu:q[5],
        br:q[6]>.5,ef,col:q[7],k:.5*E*dzP,m:q[1]*dx*dx*dzP,plate:1,
        era:q[0].includes("ERA"),nera:q[0].includes("NERA"),eraTriggered:0,s:X.length
      };
      bodies.push(B);
      let minY=1e9,maxY=-1e9;
      const coords=[];
      for(const cell of cellset){
        const [ix,iy]=cell.split(',').map(Number);
        const xm=ix*dx,ym=iy*dx;
        if(ym<minY)minY=ym;if(ym>maxY)maxY=ym;
        coords.push([xm,ym]);
      }
      const spanY=maxY-minY;
      for(const [xm,ym] of coords){
        X.push(xm);Y.push(ym);VX.push(0);VY.push(0);
        BI.push(bodies.length-1);
        FIX.push(spanY>8*dx&&(ym<minY+2*dx||ym>maxY-2*dx)?1:0);
      }
      B.e=X.length;
    });
  }

  // Projectiles
  bd.forEach((b,bi)=>{
    const k=b.k,m0=b.m/1e3,d0=b.d/1e3;
    const rb=k<.55?10800:k<.8?8500:k<1.3?7850:15600;
    const E=(k<.55?25:k<1.3?200:320)*1e9,dz=Math.PI/4*d0;
    const Lb=m0/(rb*Math.PI/4*d0*d0),r=b.dir*Math.PI/180,ux=Math.cos(r),uy=Math.sin(r);
    const matName=k<.55?"Lead":k<1.3?"Hardened steel (AR500)":"Tungsten Heavy Alloy";
    const B={
      name:BU[b.pre]?BU[b.pre][0]:'Custom Bullet',bulletIdx:bi,matName,
      E,Y:Math.min(2.0e9,(100+1900*Math.min(k,1.6)**2)*1e6),rho:rb,
      cp:k<.55?130:k<1.3?470:160,Tm:k<.55?327:k<1.3?1480:3100,
      mu:.18,br:k>=.95,ef:k<.55?.85:k<.95?.45:.35,col:k>=1.3?'#0ea5e9':'#1aa5c4',
      k:.5*E*dz,m:rb*dx*dx*dz,s:X.length,v0:b.v
    };
    bodies.push(B);
    for(let a=dx/2;a<Lb;a+=dx){
      const f=a/Lb,hw=d0/2*(f<.72?1:1-.88*(f-.72)/.28);
      for(let q=-hw+dx/2;q<hw;q+=dx){
        X.push(b.x/1e3-ux*(Lb-a)-uy*q);
        Y.push(b.y/1e3-uy*(Lb-a)+ux*q);
        VX.push(ux*b.v);VY.push(uy*b.v);
        BI.push(bodies.length-1);FIX.push(0);
      }
    }
    B.e=X.length;
  });

  const N=X.length,M=new Float64Array(N),T=new Float32Array(N).fill(20),EP=new Float32Array(N);
  const nbn=new Int32Array(N*8).fill(-1),nbb=new Int32Array(N*8),cnt=new Uint8Array(N),bi=[],bj=[],bL=[];
  for(let i=0;i<N;i++)M[i]=bodies[BI[i]].m;

  const cs=1.6*dx,key=(x,y)=>(Math.floor(x/cs)+20000)*40000+Math.floor(y/cs)+20000,G=new Map();
  for(let i=0;i<N;i++){const k=key(X[i],Y[i]);(G.get(k)||G.set(k,[]).get(k)).push(i)}
  for(let i=0;i<N;i++){
    const cx=Math.floor(X[i]/cs)+20000,cy=Math.floor(Y[i]/cs)+20000;
    for(let a=-1;a<=1;a++)for(let c=-1;c<=1;c++){
      const l=G.get((cx+a)*40000+cy+c);if(!l)continue;
      for(const j of l){
        if(j<=i||BI[j]!==BI[i]||cnt[i]>7||cnt[j]>7)continue;
        const L=Math.hypot(X[j]-X[i],Y[j]-Y[i]);
        if(L<1.5*dx){
          const b=bi.length;bi.push(i);bj.push(j);bL.push(L);
          nbn[i*8+cnt[i]]=j;nbb[i*8+cnt[i]++]=b;
          nbn[j*8+cnt[j]]=i;nbb[j*8+cnt[j]++]=b;
        }
      }
    }
  }
  let x0=-.06,y0=-.06,x1=.06,y1=.06;
  for(let i=0;i<N;i++){x0=Math.min(x0,X[i]);x1=Math.max(x1,X[i]);y0=Math.min(y0,Y[i]);y1=Math.max(y1,Y[i])}
  x0-=.09;y0-=.09;x1+=.09;y1+=.09;
  const gx=Math.max(2,Math.ceil((x1-x0)/dx)+1),gy=Math.max(2,Math.ceil((y1-y0)/dx)+1),nb=bi.length;
  const bok=new Uint8Array(nb).fill(1);
  const bLp=Float64Array.from(bL);
  const cmax=Math.max(2000,...bodies.map(B=>Math.sqrt(B.E/B.rho)||2000));
  let KE0=0;for(let i=0;i<N;i++)KE0+=.5*M[i]*(VX[i]**2+VY[i]**2);
  const alive=new Uint8Array(N).fill(1);

  PS={
    N,X:Float64Array.from(X),Y:Float64Array.from(Y),VX:Float64Array.from(VX),VY:Float64Array.from(VY),
    M,T,EP,BI:Uint8Array.from(BI),FIX:Uint8Array.from(FIX),alive,
    nbn,nbb,nb,bi:Int32Array.from(bi),bj:Int32Array.from(bj),bL0:Float64Array.from(bL),bLp,bok,
    fx:new Float64Array(N),fy:new Float64Array(N),dmg:new Uint8Array(N),
    bodies:normBodies(bodies),dx,dt:.24*dx/cmax,
    initX:Float64Array.from(X),initY:Float64Array.from(Y),initVX:Float64Array.from(VX),initVY:Float64Array.from(VY),
    initT:Float32Array.from(T),initEP:Float32Array.from(EP),initAlive:Uint8Array.from(alive),
    initBok:Uint8Array.from(bok),initBLp:Float64Array.from(bLp),initDmg:new Uint8Array(N),
    t:0,broken:0,Wp:0,Wf:0,frames:[],frameCounter:0,
    x0,y0,gx,gy,head:new Int32Array(gx*gy),nxt:new Int32Array(N),KE0,done:false
  };
  graphData={t:[0],v:[bd[0]?bd[0].v:0],ke:[KE0],f:[0]};
  updateNodeSlider();
}

function pstep(){
  const S=PS,{X,Y,VX,VY,M,T,EP,BI,fx,fy,alive,bodies,dt,dx,bok,bi,bj,bL0,bLp,dmg,head,nxt,nbn,nbb,FIX,N,gx,gy,x0,y0}=S;
  fx.fill(0);fy.fill(0);
  // 1. Bond forces + Johnson-Cook Plasticity + Heat Conduction
  for(let b=0;b<S.nb;b++){
    if(!bok[b])continue;
    const i=bi[b],j=bj[b],B=bodies[BI[i]],ex=X[j]-X[i],ey=Y[j]-Y[i],L=Math.sqrt((ex)*(ex)+(ey)*(ey))||1e-12;
    const th=Math.max(0,(.5*(T[i]+T[j])-20)/(B.Tm-20));
    // Ceramic damage softening
    const dmgSoft=B.br?Math.max(.15,1-.18*(dmg[i]+dmg[j])):1;
    const failLim=B.ef*(1+.35*th)*dmgSoft;
    if(th>=1||L>bL0[b]*(1+failLim)){
      bok[b]=0;dmg[i]=Math.min(15,dmg[i]+1);dmg[j]=Math.min(15,dmg[j]+1);S.broken++;
      // ERA reactive detonation when ERA bonds fracture under high impact
      if(B.era&&!B.eraTriggered&&S.t>2e-6){
        const vImp=Math.sqrt((VX[i])*(VX[i])+(VY[i])*(VY[i]));
        if(vImp>120){
          B.eraTriggered=1;
          const cx=.5*(X[i]+X[j]),cy=.5*(Y[i]+Y[j]),rBlast=12*dx;
          for(let k=0;k<N;k++){
            if(!alive[k]||FIX[k])continue;
            const rx=X[k]-cx,ry=Y[k]-cy,d=Math.sqrt((rx)*(rx)+(ry)*(ry));
            if(d<rBlast&&d>1e-9){
              const kick=650*(1-d/rBlast)*(bodies[BI[k]].plate?.45:1.1);
              VX[k]+=(rx/d)*kick;VY[k]+=(ry/d)*kick;
              T[k]=Math.min(3500,T[k]+450*(1-d/rBlast));
            }
          }
        }
      }
      continue;
    }
    let Lp=bLp[b];
    const epBond=Math.abs(Lp-bL0[b])/bL0[b];
    const relV=Math.abs(((VX[j]-VX[i])*ex+(VY[j]-VY[i])*ey)/L);
    const edot=Math.max(1,relV/(bL0[b]*1e3));
    const Yjc=jcFast(B,epBond,edot,th)*dmgSoft;
    const ey0=Yjc/B.E,eps=(L-Lp)/Lp;
    if(eps>ey0){
      const n=L/(1+ey0),W=B.k*ey0*Lp*(n-Lp);
      Lp=n;S.Wp+=W;
      const dEp=Math.abs(n-bLp[b])/bL0[b];EP[i]+=dEp*.5;EP[j]+=dEp*.5;
      T[i]+=.45*W/(M[i]*B.cp);T[j]+=.45*W/(M[j]*B.cp);
    }else if(eps<-ey0){
      const minComp=B.br?.55:.38;
      const n=Math.max(L/(1-ey0),minComp*bL0[b]),W=B.k*ey0*Lp*(Lp-n);
      Lp=n;S.Wp+=W;
      const dEp=Math.abs(bLp[b]-n)/bL0[b];EP[i]+=dEp*.5;EP[j]+=dEp*.5;
      T[i]+=.45*W/(M[i]*B.cp);T[j]+=.45*W/(M[j]*B.cp);
      // Brittle compressive crushing (ceramic comminution)
      if(B.br&&L<.72*bL0[b]){bok[b]=0;dmg[i]=Math.min(15,dmg[i]+1);dmg[j]=Math.min(15,dmg[j]+1);S.broken++;continue}
    }
    bLp[b]=Lp;
    // Slight thermal conduction along intact bonds
    const dT=T[j]-T[i];if(Math.abs(dT)>2){const qCond=.004*dT;T[i]+=qCond;T[j]-=qCond}
    const mr=M[i]*M[j]/(M[i]+M[j]);
    const damp=B.nera?.22:.11;
    const F=B.k*(L-Lp)+damp*Math.sqrt(B.k*mr)*((VX[j]-VX[i])*ex+(VY[j]-VY[i])*ey)/L;
    const fxx=F*ex/L,fyy=F*ey/L;
    fx[i]+=fxx;fy[i]+=fyy;fx[j]-=fxx;fy[j]-=fyy;
  }

  // 2. Spatial hash & non-bonded contact / friction
  head.fill(-1);
  for(let i=0;i<N;i++)if(alive[i]){
    const c=(((Y[i]-y0)/dx)|0)*gx+(((X[i]-x0)/dx)|0);
    if(c>=0&&c<head.length){nxt[i]=head[c];head[c]=i}
  }
  const rc=.96*dx,rc2=rc*rc;
  for(let i=0;0<N&&i<N;i++){
    if(!alive[i])continue;
    const cx=((X[i]-x0)/dx)|0,cy=((Y[i]-y0)/dx)|0;
    for(let a=-1;a<=1;a++){
      const yy=cy+a;if(yy<0||yy>=gy)continue;
      for(let c=-1;c<=1;c++){
        const xx=cx+c;if(xx<0||xx>=gx)continue;
        for(let j=head[yy*gx+xx];j>=0;j=nxt[j]){
          if(j<=i||(FIX[i]&&FIX[j]))continue;
          const ex=X[j]-X[i],ey=Y[j]-Y[i],r2=ex*ex+ey*ey;if(r2>=rc2)continue;
          let bonded=0;for(let n=0;n<8;n++)if(nbn[i*8+n]===j&&bok[nbb[i*8+n]]){bonded=1;break}
          if(bonded)continue;
          const r=Math.sqrt(r2)||1e-12,nx=ex/r,ny=ey/r,Bi=bodies[BI[i]],Bj=bodies[BI[j]];
          const kc=.55*(Bi.k+Bj.k),rvx=VX[j]-VX[i],rvy=VY[j]-VY[i],vn=rvx*nx+rvy*ny,mr=M[i]*M[j]/(M[i]+M[j]);
          const fn=kc*(rc-r)+(vn<0?.22*Math.sqrt(kc*mr)*-vn:0);
          fx[i]-=fn*nx;fy[i]-=fn*ny;fx[j]+=fn*nx;fy[j]+=fn*ny;
          const vtx=rvx-vn*nx,vty=rvy-vn*ny,vt=Math.sqrt((vtx)*(vtx)+(vty)*(vty));
          if(vt>1e-3){
            const ft=Math.min(.5*(Bi.mu+Bj.mu)*fn,.5*mr*vt/dt),tx=vtx/vt,ty=vty/vt,q=.5*ft*vt*dt;
            S.Wf+=2*q;
            fx[i]+=ft*tx;fy[i]+=ft*ty;fx[j]-=ft*tx;fy[j]-=ft*ty;
            T[i]+=q/(M[i]*Bi.cp);T[j]+=q/(M[j]*Bj.cp);
          }
        }
      }
    }
  }

  // 3. Time integration
  for(let i=0;i<N;i++){
    if(!alive[i])continue;
    if(FIX[i]){VX[i]=VY[i]=0;continue}
    if(!isFinite(fx[i])||!isFinite(fy[i])){fx[i]=0;fy[i]=0}
    VX[i]+=fx[i]/M[i]*dt;VY[i]+=fy[i]/M[i]*dt;
    if(!isFinite(VX[i])||!isFinite(VY[i])){VX[i]=VY[i]=0;alive[i]=0;continue}
    X[i]+=VX[i]*dt;Y[i]+=VY[i]*dt;
    if(!isFinite(X[i])||!isFinite(Y[i])){alive[i]=0;continue}
    if(T[i]>4000)T[i]=4000;
    if(X[i]<x0||Y[i]<y0||X[i]>x0+(gx-1)*dx||Y[i]>y0+(gy-1)*dx)alive[i]=0;
  }
  S.t+=dt;
}

const CC=new Map();
function pcol(hex,hl,dl){
  const k=hex+'_'+hl+'_'+dl;
  let c=CC.get(k);
  if(!c){
    const n=parseInt((hex||'#8a95a3').slice(1),16),m=hl/7*.9,f=1-.18*dl;
    const r=[n>>16&255,n>>8&255,n&255],o=[255,105,25];
    const redBoost=dl>=2?.3:dl>=1?.12:0;
    c='rgb('+r.map((v,i)=>Math.round(((v*(1-m)+o[i]*m)*f*(1-redBoost)+(i===0?255:40)*redBoost))).join(',')+')';
    CC.set(k,c);
  }
  return c;
}

function updateColLegend(){
  const el=$('colLegend');if(!el)return;
  const mode=$('colMode')?$('colMode').value:'mat';
  if(mode==='temp')
    el.innerHTML='Temp: <span style="display:inline-block;width:90px;height:8px;background:linear-gradient(to right,#1e3a8a,#06b6d4,#22c55e,#eab308,#ef4444,#ffffff);vertical-align:middle;border-radius:3px;margin:0 4px"></span> 20°C → Melt';
  else if(mode==='mat')
    el.innerHTML='Material color + <span style="display:inline-block;width:65px;height:8px;background:linear-gradient(to right,#8a95a3,#ff6e1e,#ffffff);vertical-align:middle;border-radius:3px;margin:0 4px"></span> thermal glow';
  else if(mode==='dmg')
    el.innerHTML='Damage: <span style="display:inline-block;width:85px;height:8px;background:linear-gradient(to right,#22c55e,#eab308,#ef4444);vertical-align:middle;border-radius:3px;margin:0 4px"></span> intact → shattered';
  else if(mode==='strain')
    el.innerHTML='Plastic strain $\\varepsilon_p$: <span style="display:inline-block;width:85px;height:8px;background:linear-gradient(to right,#1e293b,#6366f1,#ec4899,#fef08a);vertical-align:middle;border-radius:3px;margin:0 4px"></span> 0 → 0.5+';
  else if(mode==='vel')
    el.innerHTML='Speed: <span style="display:inline-block;width:85px;height:8px;background:linear-gradient(to right,#1e293b,#0ea5e9,#22c55e,#facc15,#ef4444);vertical-align:middle;border-radius:3px;margin:0 4px"></span> 0 → max m/s';
}

function drawGridAndStrokes(X,Y,C){
  const tg=70/s,p10=Math.pow(10,Math.floor(Math.log10(tg))),st=[1,2,5,10].map(a=>a*p10).find(a=>a>=tg);
  cx.strokeStyle=C('--gr');cx.lineWidth=1;cx.fillStyle=C('--mu');cx.font='11px system-ui';cx.beginPath();
  for(let x=Math.ceil(-ox/s/st)*st;X(x)<W;x+=st){cx.moveTo(X(x),0);cx.lineTo(X(x),H);cx.fillText(+x.toFixed(2)+' mm',X(x)+3,H-6)}
  for(let y=Math.ceil(-oy/s/st)*st;Y(y)<H;y+=st){cx.moveTo(0,Y(y));cx.lineTo(W,Y(y))}
  cx.stroke();

  // Drawn armor strokes overlay
  cx.save();
  cx.globalAlpha=PS&&PS.t>0?.22:.55;
  (sc.drawn||[]).forEach(sh=>{
    const col=(MA[sh.material]||MA[0])[7]||'#8a95a3';
    cx.fillStyle=col;cx.strokeStyle=col;
    if(sh.type==='brush'){
      sh.points.forEach(pt=>{cx.beginPath();cx.arc(X(pt.x),Y(pt.y),Math.max(sh.size*s,2),0,Math.PI*2);cx.fill()});
    }else{
      cx.lineWidth=Math.max(sh.size*s,2);cx.lineCap='round';cx.lineJoin='round';
      cx.beginPath();sh.points.forEach((pt,i)=>i?cx.lineTo(X(pt.x),Y(pt.y)):cx.moveTo(X(pt.x),Y(pt.y)));cx.stroke();
    }
  });
  if(drawPoints.length>0){
    cx.globalAlpha=.85;cx.fillStyle='#ff6e1e';
    drawPoints.forEach(pt=>{cx.beginPath();cx.arc(X(pt.x),Y(pt.y),Math.max(drawSize*s,2),0,Math.PI*2);cx.fill()});
    if(drawPoints.length>1){
      cx.strokeStyle='#ff6e1e';cx.lineWidth=Math.max(drawSize*s,2);cx.lineCap='round';
      cx.beginPath();drawPoints.forEach((pt,i)=>i?cx.lineTo(X(pt.x),Y(pt.y)):cx.moveTo(X(pt.x),Y(pt.y)));cx.stroke();
    }
  }
  if(drawMode==='line'&&drawPoints.length>0&&lineCursor){
    cx.globalAlpha=.9;cx.strokeStyle='#ff6e1e';cx.lineWidth=Math.max(drawSize*s,2);cx.setLineDash([6,4]);
    cx.beginPath();cx.moveTo(X(drawPoints[drawPoints.length-1].x),Y(drawPoints[drawPoints.length-1].y));
    cx.lineTo(X(lineCursor.x),Y(lineCursor.y));cx.stroke();cx.setLineDash([]);
  }
  cx.restore();
}

function drawP(){
  if(!W||!PS)return;
  const S=PS,{X:PX,Y:PY,VX,VY,T,EP,BI,alive,dmg,bodies}=S;
  const cs=getComputedStyle(document.documentElement),C=n=>cs.getPropertyValue(n).trim(),ac=C('--ac');
  const X=x=>ox+x*s,Y=y=>oy+y*s;
  cx.fillStyle=C('--cv');cx.fillRect(0,0,W,H);
  drawGridAndStrokes(X,Y,C);

  const colMode=$('colMode')?$('colMode').value:'mat';
  const L=new Map(),sz=Math.max(S.dx*1e3*s*($('shb').checked?.72:1.05),1.4);
  const vmax=Math.max(200,...sc.b.map(b=>b.v));

  for(let i=0;i<S.N;i++){
    if(!alive[i])continue;
    let k;
    if(colMode==='mat'){
      const hl=Math.min(7,Math.max(0,((T[i]-20)/450*7+.4)|0)),dl=Math.min(3,(dmg[i]/2)|0);
      k=(BI[i]<<6)|(hl<<2)|dl;
    }else if(colMode==='temp'){
      const Tm=bodies[BI[i]].Tm||1500;
      const lvl=Math.min(31,Math.max(0,((T[i]-20)/(Tm-20)*31)|0));
      k=lvl;
    }else if(colMode==='dmg'){
      k=Math.min(15,dmg[i]);
    }else if(colMode==='strain'){
      k=Math.min(31,Math.max(0,(EP[i]*60)|0));
    }else{
      const v=Math.hypot(VX[i],VY[i]);
      k=Math.min(31,Math.max(0,(v/vmax*31)|0));
    }
    let a=L.get(k);if(!a)L.set(k,a=[]);a.push(i);
  }

  for(const [k,a] of L){
    let color;
    if(colMode==='mat'){
      const bi=k>>6,hl=(k>>2)&7,dl=k&3;
      color=pcol(bodies[bi].col,hl,dl);
    }else if(colMode==='temp'){
      const t=k/31;
      let r,g,b;
      if(t<.25){const u=t/.25;r=30*(1-u)|0;g=(58+u*140)|0;b=(138+u*105)|0}
      else if(t<.5){const u=(t-.25)/.25;r=(u*234)|0;g=(198-u*19)|0;b=(243-u*235)|0}
      else if(t<.75){const u=(t-.5)/.25;r=(234+u*21)|0;g=(179-u*115)|0;b=(8+u*20)|0}
      else{const u=(t-.75)/.25;r=255;g=(64+u*191)|0;b=(28+u*227)|0}
      color=`rgb(${r},${g},${b})`;
    }else if(colMode==='dmg'){
      const d=Math.min(1,k/6);
      color=`rgb(${(34+d*220)|0},${(197-d*155)|0},${(94-d*60)|0})`;
    }else if(colMode==='strain'){
      const u=k/31;
      color=`rgb(${(30+u*225)|0},${(41+Math.sin(u*Math.PI)*140)|0},${(59+(1-u)*180)|0})`;
    }else{
      const u=k/31;
      color=`hsl(${Math.round(215*(1-u))},85%,${45+u*12}%)`;
    }
    cx.fillStyle=color;cx.beginPath();
    for(const i of a)cx.rect(X(PX[i]*1e3)-sz/2,Y(PY[i]*1e3)-sz/2,sz,sz);
    cx.fill();
  }

  if($('shb').checked){
    cx.strokeStyle='rgba(0,0,0,.35)';cx.lineWidth=1;cx.beginPath();
    for(let b=0;b<S.nb;b++)if(S.bok[b]){
      const i=S.bi[b],j=S.bj[b];
      cx.moveTo(X(PX[i]*1e3),Y(PY[i]*1e3));cx.lineTo(X(PX[j]*1e3),Y(PY[j]*1e3));
    }
    cx.stroke();
  }

  // Guides: plate labels, selection boxes, and aim vectors when t===0 or Guides checked
  if($('shv').checked){
    sc.p.forEach((p,j)=>{
      const q=MA[p.mat]||MA[0],r=p.rot*Math.PI/180;
      cx.save();cx.translate(X(p.x),Y(p.y));cx.rotate(r);
      if(S.t===0){
        cx.strokeStyle='rgba(0,0,0,.35)';cx.lineWidth=1;
        cx.strokeRect(-p.w*s/2,-p.h*s/2,p.w*s,p.h*s);
      }
      if(sel&&sel.t==='p'&&sel.i===j){
        cx.setLineDash([5,4]);cx.strokeStyle=ac;cx.lineWidth=2;
        cx.strokeRect(-p.w*s/2-3,-p.h*s/2-3,p.w*s+6,p.h*s+6);cx.setLineDash([]);
      }
      cx.fillStyle=C('--tx');cx.font='600 11px system-ui';
      cx.fillText(`${q[0]} (${p.w}mm)`,-p.w*s/2+3,-p.h*s/2-5);
      cx.restore();
    });
    if(S.t===0){
      sc.b.forEach((b,j)=>{
        const r=b.dir*Math.PI/180,Lb=Math.max(4*b.d,8)*s,w0=Math.max(b.d*s,4);
        cx.save();cx.translate(X(b.x),Y(b.y));cx.rotate(r);
        // Trajectory dashed aim line
        cx.setLineDash([4,4]);cx.strokeStyle='rgba(239,68,68,.55)';cx.lineWidth=1.2;
        cx.beginPath();cx.moveTo(4,0);cx.lineTo(140*s,0);cx.stroke();
        if(sel&&sel.t==='b'&&sel.i===j){
          cx.strokeStyle=ac;cx.lineWidth=2;
          cx.strokeRect(-Lb-4,-w0/2-4,Lb+8,w0+8);
        }
        cx.setLineDash([]);cx.restore();
      });
    }
  }
  updateColLegend();
  showP();
  drawGraph();
}

function showP(){
  const S=PS,al=S.alive;
  let n=0,Tp=20,keBullet=0,kePlate=0,maxEp=0,h='';
  for(let i=0;i<S.N;i++)if(al[i]){n++;if(S.EP[i]>maxEp)maxEp=S.EP[i]}
  S.bodies.forEach(B=>{
    let k=0,v=0,c=0,t=20;
    for(let i=B.s;i<B.e;i++)if(al[i]){
      const v2=S.VX[i]**2+S.VY[i]**2;
      k+=.5*S.M[i]*v2;v+=Math.sqrt(v2);c++;if(S.T[i]>t)t=S.T[i];
    }
    if(B.plate){Tp=Math.max(Tp,t);kePlate+=k}
    else{
      keBullet+=k;
      const vAvg=c?(v/c)|0:0;
      h+=`<p><b>${B.name}</b>: <b>${vAvg} m/s</b> avg · ${k|0} J · ${c} nodes · max ${t|0} °C</p>`;
    }
  });
  const brkPct=(S.broken/Math.max(1,S.nb)*100);
  const modeStr=brkPct>28?'Shear plugging + spallation':brkPct>9?'Ductile hole enlargement / cratering':S.t>0?'Elastic-plastic indentation':'Ready';
  $('out').innerHTML=
    `<p>t = <b>${(S.t*1e6).toFixed(1)} µs</b> · ${n} nodes · ${S.nb} bonds (<b>${brkPct.toFixed(1)}%</b> broken)</p>`+
    h+
    `<p>Peak plate temp: <b>${Tp|0} °C</b> · Peak $\\varepsilon_p$: <b>${maxEp.toFixed(2)}</b></p>`+
    `<p>Failure mode: <b>${modeStr}</b></p>`+
    (S.done?'<p class="ok">Simulation complete.</p>':'');

  // Update Energy & J-C Breakdown panel (#ea)
  const E0=Math.max(1,S.KE0);
  const pBul=Math.min(100,Math.max(0,keBullet/E0*100));
  const pPlt=Math.min(100-pBul,Math.max(0,kePlate/E0*100));
  const pHeat=Math.max(0,100-pBul-pPlt);
  $('ea').innerHTML=
    `<div class="ebar" title="Blue: Projectile KE | Green: Armor/Spall KE | Orange: Plastic & Thermal Work">`+
    `<span style="width:${pBul.toFixed(1)}%;background:#0ea5e9"></span>`+
    `<span style="width:${pPlt.toFixed(1)}%;background:#22c55e"></span>`+
    `<span style="width:${pHeat.toFixed(1)}%;background:#f97316"></span></div>`+
    `<div>• Initial 2D Slice KE: <b>${S.KE0|0} J</b></div>`+
    `<div>• Projectile KE Left: <b>${keBullet|0} J (${pBul.toFixed(0)}%)</b></div>`+
    `<div>• Armor &amp; Spall KE: <b>${kePlate|0} J (${pPlt.toFixed(0)}%)</b></div>`+
    `<div>• Plastic + Thermal Diss.: <b>${Math.max(0,S.KE0-keBullet-kePlate)|0} J (${pHeat.toFixed(0)}%)</b></div>`;

  if(!S.done&&S.t>8e-4){S.done=true;psRun=false;$('fire').textContent='Fire'}
}

function drawGraph(){
  const wrap=$('graphWrap'),g=$('graph');
  if(!wrap||!g)return;
  if(!$('shg').checked){wrap.style.display='none';return}
  wrap.style.display='block';
  const gc=g.getContext('2d'),W=g.width,H=g.height;
  const cs=getComputedStyle(document.documentElement),C=n=>cs.getPropertyValue(n).trim();
  gc.fillStyle=C('--bg');gc.fillRect(0,0,W,H);
  gc.strokeStyle=C('--ln');gc.lineWidth=1;gc.strokeRect(0,0,W,H);
  const n=graphData.t.length;
  if(n<2){
    gc.fillStyle=C('--mu');gc.font='11px system-ui';
    gc.fillText('Press Fire to record live telemetry',42,H/2+4);
    return;
  }
  const maxV=Math.max(100,...graphData.v),maxKE=Math.max(1,...graphData.ke);
  // Grid lines
  gc.strokeStyle=C('--gr');gc.beginPath();
  gc.moveTo(0,H*.5);gc.lineTo(W,H*.5);gc.stroke();
  // Velocity curve (cyan)
  gc.strokeStyle='#0ea5e9';gc.lineWidth=2;gc.beginPath();
  for(let i=0;i<n;i++){
    const x=i/(n-1)*(W-12)+6,y=H-8-(graphData.v[i]/maxV)*(H-28);
    i?gc.lineTo(x,y):gc.moveTo(x,y);
  }
  gc.stroke();
  // KE curve (orange/red)
  gc.strokeStyle='#f97316';gc.lineWidth=2;gc.beginPath();
  for(let i=0;i<n;i++){
    const x=i/(n-1)*(W-12)+6,y=H-8-(graphData.ke[i]/maxKE)*(H-28);
    i?gc.lineTo(x,y):gc.moveTo(x,y);
  }
  gc.stroke();
  gc.fillStyle='#0ea5e9';gc.font='600 10.5px system-ui';
  gc.fillText(`Vel: ${graphData.v[n-1]|0} m/s`,8,13);
  gc.fillStyle='#f97316';
  gc.fillText(`KE: ${graphData.ke[n-1]|0} J`,105,13);
  gc.fillStyle=C('--mu');
  gc.fillText(`${graphData.t[n-1].toFixed(0)} µs`,W-48,13);
}

const cv=$('cv'),cx=cv.getContext('2d');let W=0,H=0,s=6,ox=0,oy=0,first=true;
function fit(){
  const r=cv.getBoundingClientRect(),p=devicePixelRatio||1;
  W=r.width;H=r.height;cv.width=W*p;cv.height=H*p;
  cx.setTransform(p,0,0,p,0,0);
  if(first){first=false;reset()}else draw();
}
function reset(){s=Math.min(W||800,H||600)/135;ox=(W||800)*.5;oy=(H||600)*.48;draw()}

function draw(){drawP()}

const cur=()=>sel?(sel.t==='b'?sc.b:sc.p)[sel.i]:null;
function renderList(){
  $('ol').innerHTML=
    sc.b.map((b,i)=>`<button data-t="b" data-i="${i}" class="${sel&&sel.t==='b'&&sel.i===i?'on':''}">Bullet ${i+1}: ${BU[b.pre]?BU[b.pre][0]:'Custom'} (${b.v} m/s)</button>`).join('')+
    sc.p.map((p,i)=>`<button data-t="p" data-i="${i}" class="${sel&&sel.t==='p'&&sel.i===i?'on':''}">Armor ${i+1}: ${(MA[p.mat]||MA[0])[0]}, ${p.w} mm${p.rot?` (${p.rot}°)`:''}</button>`).join('');
}

function renderProps(){
  const o=cur();
  if(!o){$('pr').innerHTML='<p class="note">Click a bullet or armor plate in the scene or list to edit it.</p>';return}
  const isB=sel.t==='b',op=(a,v)=>a.map((x,i)=>`<option value="${i}"${v===i?' selected':''}>${x[0]}</option>`).join('');
  const m=MA[o.mat]||MA[0],jc=JC[m[0]];
  const matInfo=isB?'':`<p class="note">ρ ${m[1]} kg/m³ · Y ${m[2]} MPa · E ${m[9]} GPa · Tm ${m[4]} °C${jc?` · J-C (A=${jc.A}, B=${jc.B}, n=${jc.n}, C=${jc.C})`:''}</p>`;
  $('pr').innerHTML=
    (isB?`<label>Ammunition Preset</label><select data-k="pre">${op(BU,o.pre)}${o.pre<0?'<option value="-1" selected>Custom</option>':''}</select>`:`<label>Armor Material</label><select data-k="mat">${op(MA,o.mat)}</select>${matInfo}`)+
    (isB?BP:PP).map(([k,l,mn,mx,sp,u])=>`<label>${l}<b>${o[k]}${u?' '+u:''}</b></label><input type="range" data-k="${k}" data-u="${u}" min="${mn}" max="${mx}" step="${sp}" value="${o[k]}">`).join('')+
    `<label>Angle (precise)</label><div class="row"><button data-r="-15">−15°</button><button data-r="-1">−1°</button><input type="number" data-rn step="0.5" value="${o[isB?'dir':'rot']}" style="width:68px"><button data-r="1">+1°</button><button data-r="15">+15°</button><button data-r="0">0°</button></div>`;
}

function select(t,i){sel=t?{t,i}:null;renderList();renderProps()}

function upd(){
  if(v50busy)return;
  psRun=false;$('fire').textContent='Fire';
  build();updateNodeSlider();draw();
}

$('pr').addEventListener('input',e=>{
  const t=e.target,k=t.dataset.k,o=cur();if(!k||!o)return;
  if(t.tagName==='SELECT'){
    if(k==='pre'){
      const v=+t.value;if(v>=0&&BU[v]){const b=BU[v];Object.assign(o,{pre:v,d:b[1],m:b[2],v:b[3],k:b[4]});renderProps()}
    }else{o.mat=+t.value;renderProps()}
  }else{
    o[k]=+t.value;
    if(sel.t==='b'&&k!=='dir')o.pre=-1;
    const bEl=t.previousElementSibling&&t.previousElementSibling.querySelector('b');
    if(bEl)bEl.textContent=o[k]+(t.dataset.u?' '+t.dataset.u:'');
  }
  renderList();upd();
});

$('ol').onclick=e=>{const b=e.target.closest('button');if(b){select(b.dataset.t,+b.dataset.i);draw()}};
$('ab').onclick=()=>{sc.b.push(nb(2,-45,sc.b.length*14));select('b',sc.b.length-1);upd()};
$('ap').onclick=()=>{const l=sc.p[sc.p.length-1];sc.p.push(np(l?l.x+l.w+8:0,0,15,100,0,0));select('p',sc.p.length-1);upd()};
$('del').onclick=()=>{const o=cur();if(!o)return;(sel.t==='b'?sc.b:sc.p).splice(sel.i,1);select(sc.b.length?'b':sc.p.length?'p':null,0);upd()};

function startNodeRecording(){
  if(PS&&PS.t===0&&!PS.frames.length){
    PS.fireX=PS.X.slice();PS.fireY=PS.Y.slice();PS.fireVX=PS.VX.slice();PS.fireVY=PS.VY.slice();
    PS.fireT=PS.T.slice();PS.fireEP=PS.EP.slice();PS.fireAlive=PS.alive.slice();
    PS.fireBok=PS.bok.slice();PS.fireBLp=PS.bLp.slice();PS.fireDmg=PS.dmg.slice();
    PS.fireBroken=PS.broken;PS.frames=[];PS.frameCounter=0;
    recordNodeFrame();
  }
}

function truncFrames(){const S=PS;if(!S||!S.frames||!S.frames.length)return;
  S.frames=S.frames.filter(f=>f.t<=S.t+1e-15);
  const n=graphData.t.filter(x=>x<=S.t*1e6+1e-9).length;
  ['t','v','ke','f'].forEach(k=>{if(graphData[k])graphData[k]=graphData[k].slice(0,n)});}
$('fire').onclick=()=>{
  if(v50busy)return;
  if(!PS||PS.done)build();
  startNodeRecording();truncFrames();
  psRun=!psRun;
  $('fire').textContent=psRun?'Pause':'Resume';
};

$('stepBtn').onclick=()=>{
  if(v50busy)return;
  if(!PS||PS.done)build();
  startNodeRecording();truncFrames();
  psRun=false;$('fire').textContent='Resume';
  for(let i=0;i<6;i++)pstep();
  recordNodeFrame();recordGraph();updateNodeSlider();draw();
};

$('res').onchange=upd;
$('shb').onchange=draw;
$('shv').onchange=draw;
$('shg').onchange=draw;
$('colMode').onchange=draw;
$('ntm').oninput=e=>{if(PS){psRun=false;$('fire').textContent='Resume';restoreNodeFrame(+e.target.value)}};
$('rv').onclick=reset;

function rotTo(o,key,v){o[key]=Math.round((((v+180)%360+360)%360-180)*2)/2;renderProps();renderList();upd()}
$('pr').addEventListener('click',e=>{const b=e.target.closest('button[data-r]'),o=cur();if(!b||!o)return;const key=sel.t==='b'?'dir':'rot';rotTo(o,key,b.dataset.r==='0'?0:o[key]+ +b.dataset.r)});
$('pr').addEventListener('change',e=>{const o=cur();if(o&&e.target.hasAttribute('data-rn'))rotTo(o,sel.t==='b'?'dir':'rot',+e.target.value||0)});
addEventListener('keydown',e=>{
  const o=cur();if(!o||e.target.tagName==='INPUT'||e.target.tagName==='SELECT')return;
  const d='[{'.includes(e.key)?-1:']}'.includes(e.key)?1:0;
  if(d)rotTo(o,sel.t==='b'?'dir':'rot',o[sel.t==='b'?'dir':'rot']+d*(e.shiftKey?15:1));
});

$('rs').onclick=()=>{sc={b:[nb(2)],p:[np(0,0,18,100,0,0)],drawn:[]};sel={t:'b',i:0};renderList();renderProps();upd();reset()};
$('ex').onclick=()=>{
  const data=JSON.stringify({scene:sc,results:PS?{time_us:PS.t*1e6,nodes:PS.N,bonds:PS.nb,broken_bonds:PS.broken,initial_KE_J:PS.KE0}:null,telemetry:graphData},null,2);
  const blob=new Blob([data],{type:'application/json'}),url=URL.createObjectURL(blob);
  const a=document.createElement('a');a.href=url;a.download='armor-sim-results.json';a.click();URL.revokeObjectURL(url);
};
$('sv').onclick=()=>{try{localStorage.setItem('armorSimScene',JSON.stringify(sc));alert('Scene saved to browser storage.')}catch(e){alert('Save failed: '+e)}};
$('ld').onclick=()=>{try{const d=localStorage.getItem('armorSimScene');if(!d){alert('No saved scene found.');return}sc=cleanScene(JSON.parse(d));sel={t:'b',i:0};renderList();renderProps();upd();reset()}catch(e){alert('Load failed: '+e)}};
$('rts').onclick=()=>{
  if(v50busy||!PS)return;
  const S=PS;
  S.X.set(S.initX);S.Y.set(S.initY);S.VX.set(S.initVX);S.VY.set(S.initVY);
  S.T.set(S.initT);S.EP.set(S.initEP);S.alive.set(S.initAlive);
  S.bok.set(S.initBok);S.bLp.set(S.initBLp);S.dmg.set(S.initDmg);
  S.t=0;S.broken=0;S.Wp=0;S.Wf=0;S.frames=[];S.frameCounter=0;S.recEvery=5;S.done=false;
  S.bodies.forEach(B=>B.eraTriggered=0);
  graphData={t:[0],v:[sc.b[0]?sc.b[0].v:0],ke:[S.KE0],f:[0]};
  psRun=false;$('fire').textContent='Fire';updateNodeSlider();draw();
};

// Ballistic Limit (V50): binary search that runs the live node simulation (coarse spacing, bullet 1 only)
$('bl').onclick=async()=>{
  if(v50busy)return;
  if(!sc.b.length||!sc.p.length){alert('Need at least 1 bullet and 1 armor plate.');return}
  v50busy=true;psRun=false;$('fire').textContent='Fire';
  const b=sc.b[0],all=sc.b,origV=b.v,rs=$('res'),origRes=rs.value,wait=()=>new Promise(r=>setTimeout(r,0));
  let lo=50,hi=1800,ok=true;
  const sp=Math.max(.6,parseFloat(origRes)||.6);rs.value=String(sp);sc.b=[b];  // never finer than 0.6 mm here, it would take too long
  try{
    for(let it=0;it<9;it++){
      const mid=(lo+hi)/2;b.v=mid;
      $('out').innerHTML=`<p>V50 search ${it+1}/9: testing ${Math.round(mid)} m/s with ${sp} mm nodes…</p>`;
      await wait();build();
      const S=PS,r=(b.dir||0)*Math.PI/180,ux=Math.cos(r),uy=Math.sin(r),bb=S.bodies.find(B=>!B.plate);
      let maxP=-1e9;S.bodies.forEach(B=>{if(B.plate)for(let i=B.s;i<B.e;i++)maxP=Math.max(maxP,S.initX[i]*ux+S.initY[i]*uy)});
      let ke0=0;for(let i=bb.s;i<bb.e;i++)ke0+=.5*S.M[i]*(S.VX[i]**2+S.VY[i]**2);
      let pen=false,fin=false;
      while(!fin){
        const t0=performance.now();while(performance.now()-t0<25&&S.t<7e-4)pstep();
        let beyond=0,cnt=0,ke=0,vf=0;
        for(let i=bb.s;i<bb.e;i++)if(S.alive[i]){cnt++;ke+=.5*S.M[i]*(S.VX[i]**2+S.VY[i]**2);if(S.X[i]*ux+S.Y[i]*uy>maxP+S.dx){beyond++;vf+=S.VX[i]*ux+S.VY[i]*uy}}
        // perforation = most of the bullet is past the armor's rear face AND still moving forward (not just lodged in a bulge)
        if(cnt&&beyond>=.5*(bb.e-bb.s)&&vf/beyond>25){pen=true;fin=true}
        else if(!cnt||ke<.02*ke0||S.t>=7e-4)fin=true;
        await wait();
      }
      if(pen)hi=mid;else lo=mid;
    }
  }catch(err){ok=false;console.error(err)}
  const v50=Math.round((lo+hi)/2);
  sc.b=all;rs.value=origRes;v50busy=false;
  if(!ok){b.v=origV;renderList();renderProps();upd();$('out').innerHTML='<p class="bd">V50 search failed.</p>';return}
  b.v=v50;b.pre=-1;renderList();renderProps();upd();
  $('out').innerHTML=`<p class="ok"><b>V50 ballistic limit ≈ ${v50} m/s</b> (was ${origV} m/s; found with ${sp} mm nodes, so treat it as an estimate. Bullet 1 now flies at ${v50} m/s. Press Fire to watch a marginal hit.</p>`+$('out').innerHTML;
};

// Scenarios
const scenarios={
  pistol:{b:[nb(0,-42,0)],p:[np(-4,0,8,95,0,11),np(6,0,6,95,0,5)]},
  ss190:{b:[nb(2,-45,0)],p:[np(-3,0,5,95,0,4),np(5,0,10,95,0,11)]},
  rifle:{b:[nb(10,-45,0)],p:[np(0,0,12,100,0,0)]},
  lvl4:{b:[nb(12,-45,0)],p:[np(-5,0,9,100,0,8),np(7,0,14,100,0,10)]},
  sloped50:{b:[nb(16,-50,0)],p:[np(5,0,22,125,45,2)]},
  nera:{b:[nb(19,-52,0)],p:[np(-10,0,6,110,30,2),np(0,0,10,110,30,15),np(12,0,10,110,30,0)]},
  era:{b:[nb(22,-60,0)],p:[np(-12,0,10,120,40,16),np(10,0,35,120,0,0)]},
  whipple:{b:[nb(22,-60,0)],p:[np(-20,0,4,115,0,6),np(0,0,6,115,0,11),np(20,0,18,115,0,4)]}
};
$('scn').onchange=e=>{
  const v=e.target.value;if(!v||!scenarios[v])return;
  const s2=scenarios[v];
  sc={b:s2.b.map(x=>({...x})),p:s2.p.map(x=>({...x})),drawn:[]};
  sel={t:'b',i:0};renderList();renderProps();upd();reset();
  $('scn').value='';
};

function recordNodeFrame(){
  const S=PS;if(!S)return;
  if(S.frames.length>=240){S.frames=S.frames.filter((_,i)=>i%2===0);S.recEvery=(S.recEvery||5)*2}
  S.frames.push({
    t:S.t,X:Float64Array.from(S.X),Y:Float64Array.from(S.Y),
    VX:Float32Array.from(S.VX),VY:Float32Array.from(S.VY),
    T:Float32Array.from(S.T),EP:Float32Array.from(S.EP),
    alive:Uint8Array.from(S.alive),dmg:Uint8Array.from(S.dmg),
    bok:Uint8Array.from(S.bok),broken:S.broken
  });
}
function updateNodeSlider(){
  const S=PS;if(!S)return;
  const sl=$('ntm');sl.max=Math.max(0,S.frames.length-1);sl.value=S.frames.length-1;$('ntl').textContent='t = '+(S.t*1e6).toFixed(1)+' µs';
}
function restoreNodeFrame(i){
  const S=PS;if(!S||!S.frames.length)return;
  const f=S.frames[Math.max(0,Math.min(i,S.frames.length-1))];
  S.X.set(f.X);S.Y.set(f.Y);S.VX.set(f.VX);S.VY.set(f.VY);
  S.T.set(f.T);S.EP.set(f.EP);S.alive.set(f.alive);S.dmg.set(f.dmg);
  S.bok.set(f.bok);S.t=f.t;S.broken=f.broken;
  $('ntl').textContent='t = '+(S.t*1e6).toFixed(1)+' µs';
  draw();
}

function recordGraph(){
  const S=PS;if(!S)return;
  const bBody=S.bodies.find(B=>!B.plate);
  let v=0,ke=0;
  if(bBody){
    let c=0;
    for(let i=bBody.s;i<bBody.e;i++)if(S.alive[i]){
      const v2=S.VX[i]**2+S.VY[i]**2;
      v+=Math.sqrt(v2);ke+=.5*S.M[i]*v2;c++;
    }
    if(c)v/=c;
  }
  graphData.t.push(S.t*1e6);graphData.v.push(v);graphData.ke.push(ke);
}

function loop(ts){
  const spFactor=+$('sp').value||2;
  if(psRun&&PS){
    const budgetMs=spFactor<=1?15:spFactor<=2?10:spFactor<=5?4:1.5;
    const maxSteps=spFactor<=1?28:spFactor<=2?14:spFactor<=5?5:2;
    const t0=performance.now();
    let steps=0;
    while(performance.now()-t0<budgetMs&&steps<maxSteps&&PS.t<8e-4){
      pstep();steps++;
      if(PS.frameCounter++%(PS.recEvery||5)===0){recordNodeFrame();recordGraph()}
    }
    draw();updateNodeSlider();
  }
  last=ts;requestAnimationFrame(loop);
}

cv.addEventListener('wheel',e=>{
  e.preventDefault();
  const r=cv.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;
  const ns=Math.min(400,Math.max(.5,s*Math.pow(1.0015,-e.deltaY))),k=ns/s;
  ox=mx-(mx-ox)*k;oy=my-(my-oy)*k;s=ns;draw();
},{passive:false});

function pick(wx,wy){
  for(let i=sc.b.length-1;i>=0;i--){
    const b=sc.b[i],r=b.dir*Math.PI/180,ux=Math.cos(r),uy=Math.sin(r),L=Math.max(4*b.d,8);
    const a=(wx-b.x)*ux+(wy-b.y)*uy,pp=Math.abs(-(wx-b.x)*uy+(wy-b.y)*ux);
    if(a>-L-6/s&&a<6/s&&pp<b.d/2+8/s)return['b',i];
  }
  for(let i=sc.p.length-1;i>=0;i--){
    const p=sc.p[i],r=p.rot*Math.PI/180,dx=wx-p.x,dy=wy-p.y;
    const lx=dx*Math.cos(r)+dy*Math.sin(r),ly=-dx*Math.sin(r)+dy*Math.cos(r);
    if(Math.abs(lx)<p.w/2+4/s&&Math.abs(ly)<p.h/2+4/s)return['p',i];
  }
  return null;
}

let dr=null;
function eraseAt(wx,wy){
  const r=drawSize*2/s+3;
  sc.drawn=sc.drawn.filter(sh=>!sh.points.some(pt=>Math.hypot(pt.x-wx,pt.y-wy)<r));
}
function setDrawMode(m){
  drawMode=m;drawPoints=[];lineCursor=null;
  ['dmSel','dmBrush','dmLine','dmErase'].forEach(id=>$(id).classList.remove('on'));
  if(m==='select')$('dmSel').classList.add('on');
  if(m==='brush')$('dmBrush').classList.add('on');
  if(m==='line')$('dmLine').classList.add('on');
  if(m==='erase')$('dmErase').classList.add('on');
  const mi=$('modeInd');if(mi)mi.textContent=m.charAt(0).toUpperCase()+m.slice(1);
  draw();
}

const ptrs=new Map();let gst=null;
function zoomAt(mx,my,f){const ns=Math.min(400,Math.max(.5,s*f)),k=ns/s;ox=mx-(mx-ox)*k;oy=my-(my-oy)*k;s=ns;draw()}
cv.addEventListener('pointerdown',e=>{
  ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(ptrs.size===2){ // second finger: cancel the one-finger action and start a pinch/pan gesture
    isDrawing=false;if(drawMode==='brush'||drawMode==='erase')drawPoints=[];dr=null;
    const [a,b]=[...ptrs.values()],r=cv.getBoundingClientRect();
    gst={d0:Math.max(10,Math.hypot(a.x-b.x,a.y-b.y)),mx0:(a.x+b.x)/2-r.left,my0:(a.y+b.y)/2-r.top,s0:s,ox0:ox,oy0:oy};return;
  }
  if(ptrs.size>2)return;
  const r=cv.getBoundingClientRect(),wx=(e.clientX-r.left-ox)/s,wy=(e.clientY-r.top-oy)/s;
  if(drawMode==='brush'){isDrawing=true;drawPoints=[{x:wx,y:wy}];dr={draw:true};cv.setPointerCapture(e.pointerId);draw();return}
  if(drawMode==='line'){
    drawPoints.push({x:wx,y:wy});
    if(drawPoints.length>=2){
      sc.drawn.push({type:'line',points:drawPoints.slice(),material:drawMat,size:drawSize});
      drawPoints=[];lineCursor=null;upd();
    }
    draw();return;
  }
  if(drawMode==='erase'){isDrawing=true;eraseAt(wx,wy);dr={erase:true};cv.setPointerCapture(e.pointerId);draw();return}
  const h=pick(wx,wy);cv.setPointerCapture(e.pointerId);
  if(h){select(h[0],h[1]);const o=cur();dr={o,ox:wx-o.x,oy:wy-o.y};draw()}
  else dr={px:e.clientX,py:e.clientY};
});

cv.addEventListener('pointermove',e=>{
  if(ptrs.has(e.pointerId))ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(gst&&ptrs.size>=2){
    const [a,b]=[...ptrs.values()],r=cv.getBoundingClientRect(),mx=(a.x+b.x)/2-r.left,my=(a.y+b.y)/2-r.top;
    const ns=Math.min(400,Math.max(.5,gst.s0*Math.hypot(a.x-b.x,a.y-b.y)/gst.d0)),wx0=(gst.mx0-gst.ox0)/gst.s0,wy0=(gst.my0-gst.oy0)/gst.s0;
    s=ns;ox=mx-wx0*ns;oy=my-wy0*ns;draw();return;
  }
  const r=cv.getBoundingClientRect(),wx=(e.clientX-r.left-ox)/s,wy=(e.clientY-r.top-oy)/s;
  if(drawMode==='line'&&drawPoints.length>0){lineCursor={x:wx,y:wy};draw();return}
  if(!dr)return;
  if(dr.draw){
    const lastPt=drawPoints[drawPoints.length-1];
    if(!lastPt||Math.hypot(wx-lastPt.x,wy-lastPt.y)>.4){drawPoints.push({x:wx,y:wy});draw()}
    return;
  }
  if(dr.erase){eraseAt(wx,wy);draw();return}
  if(dr.o){
    dr.o.x=Math.round((wx-dr.ox)*2)/2;
    dr.o.y=Math.round((wy-dr.oy)*2)/2;
    upd();
  }else{
    ox+=e.clientX-dr.px;oy+=e.clientY-dr.py;
    dr.px=e.clientX;dr.py=e.clientY;draw();
  }
});

['pointerup','pointercancel'].forEach(t=>cv.addEventListener(t,e=>{
  ptrs.delete(e.pointerId);if(ptrs.size<2)gst=null;
  if(isDrawing&&drawMode==='brush'&&drawPoints.length>0){
    sc.drawn.push({type:'brush',points:drawPoints.slice(),material:drawMat,size:drawSize});
    drawPoints=[];isDrawing=false;upd();
  }
  if(isDrawing&&drawMode==='erase'){isDrawing=false;upd()}
  dr=null;
}));

const dmMatSel=$('dmMat');
MA.forEach((m,i)=>{const o=document.createElement('option');o.value=i;o.textContent=m[0];dmMatSel.appendChild(o)});
dmMatSel.onchange=()=>drawMat=+dmMatSel.value;
$('ds').oninput=e=>{drawSize=+e.target.value;$('dsz').textContent=drawSize+' mm'};
$('dmSel').onclick=()=>setDrawMode('select');
$('dmBrush').onclick=()=>setDrawMode('brush');
$('dmLine').onclick=()=>setDrawMode('line');
$('dmErase').onclick=()=>setDrawMode('erase');
$('dmClear').onclick=()=>{sc.drawn=[];drawPoints=[];lineCursor=null;upd()};
$('dmFinish').onclick=()=>{if(drawPoints.length>1){sc.drawn.push({type:'line',points:drawPoints.slice(),material:drawMat,size:drawSize});drawPoints=[];lineCursor=null;upd()}};

$('zin').onclick=()=>zoomAt(W/2,H/2,1.3);$('zout').onclick=()=>zoomAt(W/2,H/2,1/1.3);$('zfit').onclick=reset;
if(matchMedia('(pointer:coarse)').matches){ // touch devices (tablets): lighter default and touch hints
  $('res').value='.9';
  $('hint').innerHTML='Pinch: zoom · Drag empty space: pan · Drag object: move · Mode: <b id="modeInd">Select</b>';
}
renderList();renderProps();upd();new ResizeObserver(fit).observe(cv);fit();requestAnimationFrame(loop);


// ---------- Security: validate anything loaded from storage (never trust stored JSON) ----------
function cleanScene(d){
  if(!d||typeof d!=='object')throw new Error('invalid scene');
  const num=(v,lo,hi,def)=>{v=Number(v);return Number.isFinite(v)?Math.min(hi,Math.max(lo,v)):def};
  const out={b:[],p:[],drawn:[]};
  (Array.isArray(d.b)?d.b:[]).slice(0,12).forEach(b=>{if(b&&typeof b==='object')out.b.push({x:num(b.x,-500,500,-45),y:num(b.y,-500,500,0),dir:num(b.dir,-180,180,0),d:num(b.d,3,35,8),m:num(b.m,.5,300,8),v:num(b.v,50,1800,400),k:num(b.k,.1,1.6,.5),pre:Math.round(num(b.pre,-1,BU.length-1,-1))})});
  (Array.isArray(d.p)?d.p:[]).slice(0,30).forEach(p=>{if(p&&typeof p==='object')out.p.push({x:num(p.x,-500,500,0),y:num(p.y,-500,500,0),w:num(p.w,.5,120,10),h:num(p.h,20,300,100),rot:num(p.rot,-180,180,0),mat:Math.round(num(p.mat,0,MA.length-1,0))})});
  (Array.isArray(d.drawn)?d.drawn:[]).slice(0,300).forEach(sh=>{if(sh&&Array.isArray(sh.points))out.drawn.push({type:sh.type==='line'?'line':'brush',material:Math.round(num(sh.material,0,MA.length-1,0)),size:num(sh.size,1,10,3),points:sh.points.slice(0,500).map(q=>({x:num(q&&q.x,-500,500,0),y:num(q&&q.y,-500,500,0)}))})});
  return out;
}
